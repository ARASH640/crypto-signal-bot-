# Crypto Signal Bot
A simple Telegram bot to provide crypto signals.